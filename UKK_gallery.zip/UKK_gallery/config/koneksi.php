<?php 
$hostname = 'localhost';
$userdb = 'root';
$passdb = '';
$namedb = 'galleryfoto';

$koneksi = mysqli_connect($hostname,$userdb,$passdb,$namedb);

// if ($koneksi) {
// 	echo "Connected";
// }else{
// 	echo "Not Connected";
// }

 ?>